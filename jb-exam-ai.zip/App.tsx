
import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { FileUpload } from './components/FileUpload';
import { Quiz } from './components/Quiz';
import { ResultSummary } from './components/ResultSummary';
import { generateQuizFromContent } from './services/geminiService';
import { AppState, FileData, Question, QuizAttempt } from './types';

export default function App() {
  const [state, setState] = useState<AppState>(AppState.UPLOAD);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleFilesSelected = async (files: FileData[]) => {
    setIsLoading(true);
    try {
      // Challenging 10 questions as requested
      const generatedQuestions = await generateQuizFromContent(files, 10);
      setQuestions(generatedQuestions);
      setState(AppState.QUIZ);
    } catch (error) {
      console.error("Failed to generate quiz", error);
      alert("Something went wrong while analyzing your files. Our examiner model might be under high load. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuizFinish = (results: QuizAttempt[]) => {
    setAttempts(results);
    setState(AppState.RESULTS);
  };

  const resetApp = () => {
    setState(AppState.UPLOAD);
    setQuestions([]);
    setAttempts([]);
  };

  const handleModuleUnderstood = () => {
    // Show a small success feedback or just return to home
    console.log("Module understood by user.");
    resetApp();
  };

  return (
    <Layout>
      <div className="animate-in">
        {state === AppState.UPLOAD && (
          <FileUpload onFilesSelected={handleFilesSelected} isLoading={isLoading} />
        )}

        {state === AppState.QUIZ && (
          <Quiz questions={questions} onFinish={handleQuizFinish} />
        )}

        {state === AppState.RESULTS && (
          <ResultSummary 
            attempts={attempts} 
            questions={questions} 
            onRestart={resetApp}
            onUnderstood={handleModuleUnderstood}
          />
        )}
      </div>
    </Layout>
  );
}
