
import React from 'react';
import { Question, QuizAttempt } from '../types';

interface ResultSummaryProps {
  attempts: QuizAttempt[];
  questions: Question[];
  onRestart: () => void;
  onUnderstood: () => void;
}

export const ResultSummary = ({ attempts, questions, onRestart, onUnderstood }: ResultSummaryProps) => {
  const earned = attempts.reduce((s, a) => s + a.pointsEarned, 0);
  const total = questions.reduce((s, q) => s + q.points, 0);
  const percent = total > 0 ? Math.round((earned / total) * 100) : 0;

  const getStatus = () => {
    if (percent >= 90) return { msg: "Expert Mastery!", color: "text-indigo-600" };
    if (percent >= 70) return { msg: "Solid Understanding", color: "text-green-600" };
    if (percent >= 50) return { msg: "Developing Skills", color: "text-amber-600" };
    return { msg: "Review Recommended", color: "text-red-600" };
  };

  const status = getStatus();

  return (
    <div className="bg-white rounded-[2.5rem] border border-slate-200 p-10 text-center animate-scale shadow-2xl shadow-indigo-500/5 max-w-3xl mx-auto">
      <div className="mb-8 inline-flex p-5 bg-indigo-50 rounded-3xl animate-fade">
        <svg className="w-10 h-10 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>

      <h2 className="text-4xl font-black text-slate-900 mb-2">Exam Complete</h2>
      <p className="text-slate-400 font-bold text-xs uppercase tracking-[0.2em] mb-12">JB Exam AI • Evaluated by Jean Bosco</p>
      
      <div className="flex flex-col items-center mb-12">
        <div className="relative inline-block">
          <div className={`text-9xl font-black leading-none gradient-text`}>{percent}%</div>
          <div className="absolute -top-4 -right-10 bg-slate-900 text-white text-[10px] px-3 py-1 rounded-full font-black tracking-widest shadow-xl">FINAL</div>
        </div>
        <div className={`mt-8 px-8 py-3 rounded-2xl bg-slate-50 border border-slate-100 font-bold text-lg ${status.color}`}>
          {status.msg}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-12">
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
          <div className="text-2xl font-black text-slate-800">{earned}</div>
          <div className="text-[10px] uppercase text-slate-400 font-bold tracking-wider">Earned</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
          <div className="text-2xl font-black text-slate-800">{total}</div>
          <div className="text-[10px] uppercase text-slate-400 font-bold tracking-wider">Target</div>
        </div>
        <div className="p-4 rounded-2xl bg-green-50 border border-green-100">
          <div className="text-2xl font-black text-green-600">{attempts.filter(r => r.isCorrect).length}</div>
          <div className="text-[10px] uppercase text-green-400 font-bold tracking-wider">Correct</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
          <div className="text-2xl font-black text-slate-400">{attempts.filter(r => r.isSkipped).length}</div>
          <div className="text-[10px] uppercase text-slate-400 font-bold tracking-wider">Skipped</div>
        </div>
      </div>

      <div className="text-left mb-12 bg-slate-50/50 rounded-3xl p-6 border border-slate-100">
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 px-2">Detailed performance breakdown</h3>
        <div className="space-y-4 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
          {attempts.map((r, i) => (
            <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-white border border-slate-100 hover:border-indigo-200 transition-colors shadow-sm">
              <div className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black ${r.isCorrect ? 'bg-green-100 text-green-700' : r.isSkipped ? 'bg-slate-200 text-slate-500' : 'bg-red-100 text-red-700'}`}>
                  {i + 1}
                </div>
                <div className="flex flex-col">
                    <span className="font-bold text-slate-700 text-sm">Question {i+1}</span>
                    <span className="text-[10px] font-medium text-slate-400">{questions[i]?.points} Points possible</span>
                </div>
              </div>
              <div className={`font-black px-4 py-1.5 rounded-xl text-[10px] uppercase tracking-widest ${r.isSkipped ? 'text-slate-400 bg-slate-50' : r.isCorrect ? 'text-green-600 bg-green-50' : 'text-red-600 bg-red-50'}`}>
                {r.isSkipped ? 'Skipped' : r.isCorrect ? 'Success' : 'Fail'}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <button 
          onClick={onRestart} 
          className="flex-1 bg-white border-2 border-slate-200 text-slate-600 font-bold py-5 rounded-2xl transition-all hover:bg-slate-50 hover:border-slate-300 active:scale-95 text-sm"
        >
          Start Over
        </button>
        <button 
          onClick={onUnderstood} 
          className="flex-[2] bg-slate-900 text-white font-bold py-5 rounded-2xl transition-all hover:bg-slate-800 shadow-2xl shadow-slate-900/10 active:scale-95 flex items-center justify-center gap-2 text-sm"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          Understood Module
        </button>
      </div>
    </div>
  );
};
