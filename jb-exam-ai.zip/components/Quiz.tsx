
import React, { useState } from 'react';
import { Question, QuizAttempt } from '../types';
import { evaluateAnswer } from '../services/geminiService';

interface QuizProps {
  questions: Question[];
  onFinish: (results: QuizAttempt[]) => void;
}

export const Quiz = ({ questions, onFinish }: QuizProps) => {
  const [idx, setIdx] = useState(0);
  const [ans, setAns] = useState('');
  const [results, setResults] = useState<QuizAttempt[]>([]);
  const [evaluating, setEvaluating] = useState(false);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; feedback: string } | null>(null);

  const q = questions[idx];
  const prog = ((idx + (feedback ? 1 : 0)) / questions.length) * 100;

  const handleNext = (isSkip = false) => {
    let currentResults = [...results];
    
    // If skipping, push the skipped attempt immediately
    if (isSkip) {
      currentResults.push({ 
        questionId: q.id, 
        isCorrect: false, 
        isSkipped: true, 
        pointsEarned: 0, 
        userAnswer: '[SKIPPED]' 
      });
    }
    
    if (idx < questions.length - 1) {
      setIdx(idx + 1);
      setAns('');
      setFeedback(null);
      if (isSkip) setResults(currentResults);
    } else {
      onFinish(isSkip ? currentResults : results);
    }
  };

  const check = async () => {
    if (!ans) return;
    setEvaluating(true);
    try {
      const res = await evaluateAnswer(q, ans);
      const attempt: QuizAttempt = { 
        questionId: q.id, 
        userAnswer: ans, 
        isCorrect: res.isCorrect, 
        isSkipped: false, 
        feedback: res.feedback, 
        pointsEarned: res.isCorrect ? q.points : 0 
      };
      setFeedback(res);
      setResults(prev => [...prev, attempt]);
    } catch (error) {
        console.error("Evaluation failed", error);
        alert("Examiner is taking a break. Let's try that again.");
    } finally {
      setEvaluating(false);
    }
  };

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <div className="bg-white rounded-full h-2.5 w-full overflow-hidden shadow-inner border border-slate-200">
        <div 
          className="h-full bg-indigo-600 transition-all duration-1000 ease-[cubic-bezier(0.19, 1, 0.22, 1)]" 
          style={{ width: `${prog}%` }} 
        />
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-indigo-900/5 border border-slate-200 p-8 sm:p-12 animate-scale relative overflow-hidden">
        <div className="flex justify-between items-center mb-10">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-xl uppercase tracking-widest">
              Exam Item {idx + 1} / {questions.length}
            </span>
            <span className="text-[10px] font-black text-slate-400 bg-slate-50 px-3 py-1.5 rounded-xl uppercase tracking-widest">
              {q.points} Points
            </span>
          </div>
          <div className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{q.type}</div>
        </div>

        <h3 className="text-2xl sm:text-3xl font-bold text-slate-800 mb-10 leading-tight tracking-tight">{q.text}</h3>

        {!feedback ? (
          <div className="space-y-4 animate-fade">
            {q.type === 'MCQ' && (
              <div className="grid gap-4">
                {q.options?.map((o, i) => (
                  <button 
                    key={i} 
                    onClick={() => setAns(o)} 
                    className={`w-full text-left p-6 rounded-2xl border-2 transition-all duration-200 active:scale-[0.98] ${
                      ans === o ? 'border-indigo-600 bg-indigo-50 shadow-lg ring-4 ring-indigo-600/5' : 'border-slate-100 hover:border-indigo-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-5">
                       <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black ${ans === o ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-400'}`}>
                        {String.fromCharCode(65 + i)}
                       </span>
                       <span className={`font-semibold ${ans === o ? 'text-indigo-900' : 'text-slate-600'}`}>{o}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
            
            {q.type === 'TF' && (
              <div className="grid grid-cols-2 gap-6">
                {['True', 'False'].map(o => (
                  <button 
                    key={o} 
                    onClick={() => setAns(o)} 
                    className={`p-10 rounded-2xl border-2 font-black text-xl transition-all duration-200 active:scale-[0.98] ${
                      ans === o ? 'border-indigo-600 bg-indigo-50 shadow-lg ring-4 ring-indigo-600/5 text-indigo-700' : 'border-slate-100 hover:border-indigo-200 hover:bg-slate-50 text-slate-400'
                    }`}
                  >
                    {o}
                  </button>
                ))}
              </div>
            )}

            {q.type === 'OPEN' && (
              <textarea 
                className="w-full p-6 border-2 border-slate-100 rounded-3xl h-44 focus:ring-8 focus:ring-indigo-600/5 focus:border-indigo-600 outline-none transition-all text-slate-700 font-medium resize-none bg-slate-50/50 text-lg placeholder:text-slate-300" 
                placeholder="Synthesize your knowledge here..." 
                value={ans} 
                onChange={e => setAns(e.target.value)} 
              />
            )}

            <div className="flex gap-4 pt-10">
              <button 
                onClick={() => handleNext(true)} 
                className="flex-1 py-4 text-slate-400 font-black hover:text-slate-600 transition-colors uppercase text-[10px] tracking-widest"
              >
                Skip Question
              </button>
              <button 
                onClick={check} 
                disabled={!ans || evaluating} 
                className="flex-[2] bg-slate-900 hover:bg-slate-800 text-white font-bold py-5 rounded-2xl transition-all disabled:opacity-20 shadow-2xl shadow-slate-900/20 active:scale-95 text-sm"
              >
                {evaluating ? (
                  <span className="flex items-center justify-center gap-3">
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    Reviewing Knowledge...
                  </span>
                ) : 'Submit Final Answer'}
              </button>
            </div>
          </div>
        ) : (
          <div className={`p-8 rounded-[2rem] animate-in ${feedback.isCorrect ? 'bg-green-50/60 border-2 border-green-100' : 'bg-red-50/60 border-2 border-red-100'}`}>
            <div className="flex items-center gap-4 mb-6">
               <div className={`p-3 rounded-2xl shadow-sm ${feedback.isCorrect ? 'bg-white text-green-600' : 'bg-white text-red-600'}`}>
                  {feedback.isCorrect ? (
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                  ) : (
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                  )}
               </div>
               <div>
                  <h4 className={`font-black text-xl uppercase tracking-tighter ${feedback.isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                    {feedback.isCorrect ? 'Mastery Confirmed' : 'Review Required'}
                  </h4>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{feedback.isCorrect ? `+${q.points} Points Earned` : '0 Points Awarded'}</div>
               </div>
            </div>
            <p className={`text-sm mb-8 leading-relaxed font-semibold ${feedback.isCorrect ? 'text-green-700' : 'text-red-700'}`}>
              {feedback.feedback}
            </p>
            <div className="bg-white/80 p-6 rounded-2xl mb-10 border border-white/50 backdrop-blur-xl">
              <span className="text-[10px] font-black text-indigo-600/40 uppercase tracking-widest block mb-3">Examiner's Note</span>
              <p className="text-xs text-slate-500 font-bold leading-relaxed">{q.explanation}</p>
            </div>
            <button 
              onClick={() => handleNext(false)} 
              className="w-full bg-slate-900 text-white py-5 rounded-2xl font-bold shadow-2xl shadow-slate-900/10 transition-all hover:bg-slate-800 active:scale-95 text-sm"
            >
              {idx < questions.length - 1 ? 'Next Challenge' : 'Finish Exam & See Results'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
