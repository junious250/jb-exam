
import React, { useState, useRef } from 'react';
import { FileData } from '../types';

interface FileUploadProps {
  onFilesSelected: (files: FileData[]) => void;
  isLoading: boolean;
}

export const FileUpload = ({ onFilesSelected, isLoading }: FileUploadProps) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFiles = async () => {
    if (selectedFiles.length === 0) return;
    const processed = await Promise.all(selectedFiles.map(file => {
      return new Promise<FileData>(resolve => {
        const reader = new FileReader();
        reader.onloadend = () => resolve({ 
          name: file.name, 
          type: file.type || 'application/octet-stream', 
          data: reader.result as string 
        });
        reader.readAsDataURL(file);
      });
    }));
    onFilesSelected(processed);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 animate-in">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Ready to Study?</h2>
        <p className="text-slate-500 mt-2">Upload your notes to generate a 10-question exam by Jean Bosco.</p>
      </div>
      <div 
        onClick={() => fileInputRef.current?.click()}
        className="border-2 border-dashed border-slate-300 rounded-xl p-12 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/30 transition-all group"
      >
        <svg className="w-12 h-12 text-slate-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
        <p className="text-slate-600 font-medium">Click to upload any document</p>
        <input type="file" multiple className="hidden" ref={fileInputRef} onChange={e => setSelectedFiles(Array.from(e.target.files || []))} />
      </div>
      {selectedFiles.length > 0 && (
        <div className="mt-6">
          <div className="space-y-2 mb-6">
            {selectedFiles.map((f, i) => <div key={i} className="text-sm text-slate-600 bg-slate-50 p-2 rounded truncate max-w-full">{f.name}</div>)}
          </div>
          <button 
            onClick={processFiles} disabled={isLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
          >
            {isLoading ? <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" /> : "Generate 10 Questions Exam"}
          </button>
        </div>
      )}
    </div>
  );
};
