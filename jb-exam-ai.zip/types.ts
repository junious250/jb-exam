
// Shared types for the JB Exam AI application
export enum AppState {
  UPLOAD = 'upload',
  QUIZ = 'quiz',
  RESULTS = 'results'
}

export interface FileData {
  name: string;
  type: string;
  data: string;
}

export interface Question {
  id: string;
  text: string;
  type: 'MCQ' | 'TF' | 'OPEN';
  options: string[];
  correctAnswer: any;
  explanation: string;
  points: number;
}

export interface QuizAttempt {
  questionId: string;
  userAnswer: any;
  isCorrect: boolean;
  isSkipped: boolean;
  feedback?: string;
  pointsEarned: number;
}
