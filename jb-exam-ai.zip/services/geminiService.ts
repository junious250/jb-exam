
import { GoogleGenAI } from "@google/genai";
import { FileData, Question } from "../types";

const AI_MODEL = 'gemini-3-flash-preview';

/**
 * Generates a comprehensive and challenging exam based on provided materials.
 * Ensures 10 questions that cover all topics found in the notes.
 */
export async function generateQuizFromContent(files: FileData[], questionCount: number = 10): Promise<Question[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const parts = files.map(file => ({
    inlineData: {
      mimeType: file.type,
      data: file.data.split(',')[1] || file.data
    }
  }));

  const prompt = `You are a strict high-level academic examiner. 
  Task: Create a rigorous ${questionCount}-question exam based on the attached study materials.
  
  Critical Requirements:
  1. Topic Coverage: Analyze every part of the provided notes. Ensure no major topic is left out of the exam.
  2. Difficulty Level: Focus on "Mastery". Avoid simple definitions. Use scenarios, application-based questions, and deep conceptual analysis.
  3. Format Mix: Provide a balance of Multiple Choice (MCQ), True/False (TF), and Open-ended (OPEN) questions.
  4. Scoring: Assign a point value (points) between 5 and 20 to each question based on its complexity.
  5. Structure: Return ONLY a raw JSON array: [{id, text, type: "MCQ"|"TF"|"OPEN", options: [], correctAnswer, explanation, points}].
  
  Make the exam intellectually stimulating.`;

  const response = await ai.models.generateContent({
    model: AI_MODEL,
    contents: { parts: [...parts, { text: prompt }] },
    config: { 
      responseMimeType: "application/json"
    }
  });

  return JSON.parse(response.text || '[]');
}

/**
 * Evaluates a user's answer for correctness and provides constructive feedback.
 */
export async function evaluateAnswer(question: Question, userAnswer: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Examiner Role: Grade this student's response.
  Question: ${question.text}
  Expected Knowledge: ${question.correctAnswer}
  Student Answer: ${userAnswer}
  
  Task: Check if the student correctly understood the concept. For open questions, be flexible on wording but strict on content accuracy.
  Return JSON: { "isCorrect": boolean, "feedback": "string (brief explanation of why or correction)" }`;
  
  const response = await ai.models.generateContent({
    model: AI_MODEL,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });
  
  return JSON.parse(response.text || '{}');
}
